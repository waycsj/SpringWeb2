package org.example.springweb.controller;

import org.example.springweb.Domain.*;
import org.example.springweb.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class PostController {
  private final PostService postService;

  @Autowired
  public PostController(PostService postService) {
    this.postService = postService;
  }

  @GetMapping("/posts/likes")
  public List<PostAllResponseDto> viewAllPostsWithLikes(
      @RequestParam(name ="likes", required = false) Integer likes,
      @RequestParam(name ="title", required = false) String title
      ) {
    return postService.getAllPostsWithLikes(likes, title);
  }

  @GetMapping("/posts")
  public List<PostAllResponseDto> viewAllPosts() {
//    return "View All Posts";
    return postService.getAllPosts();
  }

  @GetMapping("/posts/{postId}")
  public PostDetailResponseDto viewPostDetail(@PathVariable("postId") int postId) {
    return postService.getPostDetail(postId);
  }

  @DeleteMapping("/posts/{postId}")
  public String deletePost(@PathVariable("postId") int postId) {
    postService.removePost(postId);
    return "삭제 완료";
  }

  @PutMapping("/posts/{postId}")
  public int updateLikesPost(@PathVariable("postId") int postId) {
    return postService.increaseLikes(postId);
  }

  @PostMapping("/posts")
  public PostDetailResponseDto createNewPost(@RequestBody PostCreateRequestDto postDto) {
    return postService.createPost(postDto);
  }

  @PatchMapping("/posts/{postId}")
  public PostDetailResponseDto updateBodyPost(@PathVariable("postId") int postId, @RequestBody PostUpdateRequestDto postDto) {
    return postService.updatePost(postDto);
  }
}